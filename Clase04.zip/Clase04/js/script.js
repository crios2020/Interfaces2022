//Implementación externa
//alert('Implementación externa')


//Comentarios
/* bloque de comentarios */

//Imprime en consola del browser
console.log('Hola Mundo JS!!')

var miMensaje = 'Hola soy un programa en JS'
console.log(miMensaje)

//imprime en el DOM
//No se puede llamar desde css ni maquetar
//document.write(miMensaje)

// DOM Document Object Model
var saludo = document.getElementById("saludo")
var fecha = document.getElementById("fecha")
var seccion = document.getElementById("seccion")

saludo.innerHTML = "Hola a todos!"

var date = new Date()

var mes = "";
if (date.getMonth() == 0) mes = "Enero";
if (date.getMonth() == 1) mes = "Febrero";
if (date.getMonth() == 2) mes = "Marzo";
if (date.getMonth() == 3) mes = "Abril";
if (date.getMonth() == 4) mes = "Mayo";
if (date.getMonth() == 5) mes = "Junio";
if (date.getMonth() == 6) mes = "Julio";
if (date.getMonth() == 7) mes = "Agosto";
if (date.getMonth() == 8) mes = "Septiembre";
if (date.getMonth() == 9) mes = "Octubre";
if (date.getMonth() == 10) mes = "Noviembre";
if (date.getMonth() == 11) mes = "Diciembre";

var textoFecha = date.getDate() + " de " + mes + " de " + date.getFullYear()

fecha.innerHTML = textoFecha

seccion.innerHTML = "Hoy es Viernes!"


//Eventos en JS
fecha.onmouseover = mouseOver
fecha.onmouseleave = mouseLeave

var body = document.getElementById("body")

function mouseOver() {
    console.log("El mouse esta sobre el elemnto!")
    fecha.style.color = 'black'
    fecha.style.backgroundColor = 'white'
    saludo.style.color = 'green'
    body.style.backgroundColor = 'black'
}

function mouseLeave() {
    console.log("El mouse ya no esta sobre el elemento")
    fecha.style.color = ''
    fecha.style.backgroundColor = ''
    saludo.style.color = ''
    body.style.backgroundColor = ''
}

function reset() {
    document.getElementById("contador").innerHTML = 0
}

function incrementar() {
    var nro = document.getElementById("contador").innerHTML
    nro++
    document.getElementById("contador").innerHTML = nro
}

function decrementar() {
    var nro = document.getElementById("contador").innerHTML
    nro--
    document.getElementById("contador").innerHTML = nro
}