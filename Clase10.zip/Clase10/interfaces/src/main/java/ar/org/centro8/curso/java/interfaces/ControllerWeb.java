package ar.org.centro8.curso.java.interfaces;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerWeb{
	@GetMapping("/")
	public String index(Model model){
		return "index";
	}

    @GetMapping("/clientes")
	public String clientes(Model model){
		return "clientes";
	}

    @GetMapping("/articulos")
	public String articulos(Model model){
		return "articulos";
	}

    @GetMapping("/facturas")
	public String facturas(Model model){
		return "facturas";
	}
}